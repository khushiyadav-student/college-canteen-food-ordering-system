import unittest
import tempfile
from pathlib import Path
import app as canteen

class CanteenSmokeTests(unittest.TestCase):
    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory()
        canteen.DB_PATH = Path(self.temp_dir.name) / "test.db"
        canteen.init_db()
        self.client = canteen.app.test_client()

    def tearDown(self):
        self.temp_dir.cleanup()

    def test_home_page_shows_menu(self):
        response = self.client.get("/")
        self.assertEqual(response.status_code, 200)
        self.assertIn(b"Today's Menu", response.data)

    def test_health_endpoint(self):
        response = self.client.get("/health")
        self.assertEqual(response.status_code, 200)
        self.assertIn(b"ok", response.data)

    def test_order_requires_customer_details(self):
        response = self.client.post("/place-order", data={})
        self.assertEqual(response.status_code, 302)

if __name__ == "__main__":
    unittest.main()

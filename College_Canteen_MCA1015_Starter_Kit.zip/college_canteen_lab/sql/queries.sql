-- 1. Retrieve all available food items
SELECT item_id, item_name, price
FROM FoodItem
WHERE available = 1;

-- 2. Filter menu items priced below Rs. 50
SELECT item_name, price
FROM FoodItem
WHERE price < 50
ORDER BY price;

-- 3. Show each order, student and status (relationship/JOIN query)
SELECT Student.name, Orders.order_id, Orders.order_date, Orders.status
FROM Student
JOIN Orders ON Student.student_id = Orders.student_id
ORDER BY Orders.order_id DESC;

-- 4. Show order items and subtotals for every order
SELECT Orders.order_id, FoodItem.item_name, OrderItem.quantity,
       OrderItem.unit_price,
       OrderItem.quantity * OrderItem.unit_price AS subtotal
FROM Orders
JOIN OrderItem ON Orders.order_id = OrderItem.order_id
JOIN FoodItem ON OrderItem.item_id = FoodItem.item_id;

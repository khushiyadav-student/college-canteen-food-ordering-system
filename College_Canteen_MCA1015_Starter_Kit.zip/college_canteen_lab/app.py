from flask import Flask, render_template, request, redirect, url_for, flash
import sqlite3
from pathlib import Path

app = Flask(__name__)
app.secret_key = "replace-this-for-real-deployment"
DB_PATH = Path(__file__).with_name("canteen.db")

MENU = [
    ("Veg Sandwich", 50.0, 1),
    ("Poha", 30.0, 1),
    ("Masala Dosa", 70.0, 1),
    ("Veg Burger", 60.0, 1),
    ("Tea", 15.0, 1),
    ("Samosa", 20.0, 1),
]

def get_db():
    connection = sqlite3.connect(DB_PATH)
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA foreign_keys = ON")
    return connection

def init_db():
    with get_db() as db:
        db.executescript("""
        CREATE TABLE IF NOT EXISTS Student (
            student_id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            email TEXT NOT NULL UNIQUE
        );
        CREATE TABLE IF NOT EXISTS FoodItem (
            item_id INTEGER PRIMARY KEY AUTOINCREMENT,
            item_name TEXT NOT NULL UNIQUE,
            price REAL NOT NULL CHECK(price >= 0),
            available INTEGER NOT NULL DEFAULT 1 CHECK(available IN (0,1))
        );
        CREATE TABLE IF NOT EXISTS Orders (
            order_id INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id INTEGER NOT NULL,
            order_date TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            status TEXT NOT NULL DEFAULT 'Placed'
                CHECK(status IN ('Placed','Preparing','Ready','Collected','Cancelled')),
            FOREIGN KEY(student_id) REFERENCES Student(student_id)
        );
        CREATE TABLE IF NOT EXISTS OrderItem (
            order_item_id INTEGER PRIMARY KEY AUTOINCREMENT,
            order_id INTEGER NOT NULL,
            item_id INTEGER NOT NULL,
            quantity INTEGER NOT NULL CHECK(quantity > 0),
            unit_price REAL NOT NULL CHECK(unit_price >= 0),
            FOREIGN KEY(order_id) REFERENCES Orders(order_id) ON DELETE CASCADE,
            FOREIGN KEY(item_id) REFERENCES FoodItem(item_id)
        );
        """)
        count = db.execute("SELECT COUNT(*) FROM FoodItem").fetchone()[0]
        if count == 0:
            db.executemany(
                "INSERT INTO FoodItem(item_name, price, available) VALUES (?, ?, ?)",
                MENU
            )

@app.route("/")
def index():
    with get_db() as db:
        items = db.execute(
            "SELECT * FROM FoodItem WHERE available=1 ORDER BY item_id"
        ).fetchall()
    return render_template("index.html", items=items)

@app.route("/place-order", methods=["POST"])
def place_order():
    name = request.form.get("name", "").strip()
    email = request.form.get("email", "").strip().lower()
    quantities = request.form.getlist("quantity")
    item_ids = request.form.getlist("item_id")

    if not name or not email:
        flash("Please enter your name and email.")
        return redirect(url_for("index"))

    selected = []
    with get_db() as db:
        for item_id, quantity in zip(item_ids, quantities):
            try:
                q = int(quantity)
                iid = int(item_id)
            except ValueError:
                continue
            if q > 0:
                item = db.execute(
                    "SELECT * FROM FoodItem WHERE item_id=? AND available=1", (iid,)
                ).fetchone()
                if item:
                    selected.append((item, q))

        if not selected:
            flash("Please select at least one food item with quantity above zero.")
            return redirect(url_for("index"))

        db.execute(
            "INSERT OR IGNORE INTO Student(name, email) VALUES (?, ?)", (name, email)
        )
        student = db.execute("SELECT student_id FROM Student WHERE email=?", (email,)).fetchone()
        cursor = db.execute("INSERT INTO Orders(student_id, status) VALUES (?, 'Placed')",
                            (student["student_id"],))
        order_id = cursor.lastrowid
        for item, quantity in selected:
            db.execute(
                "INSERT INTO OrderItem(order_id, item_id, quantity, unit_price) VALUES (?, ?, ?, ?)",
                (order_id, item["item_id"], quantity, item["price"])
            )
        db.commit()

    return redirect(url_for("order_status", order_id=order_id))

@app.route("/orders/<int:order_id>")
def order_status(order_id):
    with get_db() as db:
        order = db.execute("""
            SELECT Orders.order_id, Orders.order_date, Orders.status, Student.name, Student.email
            FROM Orders JOIN Student ON Student.student_id=Orders.student_id
            WHERE Orders.order_id=?
        """, (order_id,)).fetchone()
        if not order:
            return "Order not found", 404
        items = db.execute("""
            SELECT FoodItem.item_name, OrderItem.quantity, OrderItem.unit_price,
                   (OrderItem.quantity * OrderItem.unit_price) AS subtotal
            FROM OrderItem JOIN FoodItem ON FoodItem.item_id=OrderItem.item_id
            WHERE OrderItem.order_id=?
        """, (order_id,)).fetchall()
    total = sum(row["subtotal"] for row in items)
    return render_template("order.html", order=order, items=items, total=total)

@app.route("/staff")
def staff():
    with get_db() as db:
        orders = db.execute("""
            SELECT Orders.order_id, Orders.order_date, Orders.status, Student.name
            FROM Orders JOIN Student ON Student.student_id=Orders.student_id
            ORDER BY Orders.order_id DESC
        """).fetchall()
    return render_template("staff.html", orders=orders)

@app.route("/staff/update/<int:order_id>", methods=["POST"])
def update_status(order_id):
    status = request.form.get("status", "")
    allowed = {"Placed", "Preparing", "Ready", "Collected", "Cancelled"}
    if status not in allowed:
        flash("Invalid status.")
        return redirect(url_for("staff"))
    with get_db() as db:
        db.execute("UPDATE Orders SET status=? WHERE order_id=?", (status, order_id))
        db.commit()
    flash(f"Order #{order_id} status updated.")
    return redirect(url_for("staff"))

@app.route("/health")
def health():
    return {"status": "ok"}

init_db()

if __name__ == "__main__":
    app.run(debug=True)

# Campus Canteen Food Ordering System

A beginner-friendly educational prototype for MCA1015 Software Engineering and Project Management Lab.

## Features
- View a canteen menu and prices
- Search is a possible future enhancement; current menu is displayed as a list of cards
- Select item quantities and calculate the estimated bill in the browser
- Place a demo order and store it in SQLite
- View order summary and status
- Staff dashboard to update order status
- Automated smoke tests with GitHub Actions

## Technology
- Frontend: HTML, CSS, JavaScript
- Backend: Python + Flask
- Database: SQLite
- CI: GitHub Actions

## Run locally (Windows)
1. Install Python 3.12 or another compatible Python 3 version.
2. Open this folder in VS Code.
3. In the VS Code terminal run:

   ```powershell
   py -m venv .venv
   .\.venv\Scripts\Activate.ps1
   python -m pip install -r requirements.txt
   python app.py
   ```

4. Open `http://127.0.0.1:5000` in your browser.
5. Open `http://127.0.0.1:5000/staff` to see the staff dashboard.

If PowerShell blocks virtual-environment activation, run `.\.venv\Scripts\python.exe -m pip install -r requirements.txt`, then `.\.venv\Scripts\python.exe app.py`.

## Important limitations
This is a classroom prototype, not a production payment system. It does not process real payments, verify student accounts, or provide production-grade authentication. The staff page is not password-protected. Do not use real personal data.

## SQL evidence
SQLite database `canteen.db` is created when the app starts. Example queries are in `sql/queries.sql`.
